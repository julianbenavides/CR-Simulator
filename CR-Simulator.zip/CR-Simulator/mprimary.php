<?php
	include "config.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>Mobile Primary Users - CR Simulator</title>
	<meta http-equiv="content-type" content="text/html;charset=utf-8" />
	<link rel="stylesheet" type="text/css" href="css/styles.css" />
	<script src="js/scripts.js">
</head>
<body>
	<div class="wrapper">
		<div class="header"></div>
		<div class="leftcolumn"></div>
		<div class="content">
			
			<?php 
				/* following statement will define which layout to show possible layouts:
				Startup layout (to choose between single or multiple users
				Single Primary User Simulator Layout
				Multiple Primary Users Simulator Layout
				Simulator in process - constantly refreshing */ 
			?>

			<?php if(empty($_GET)) : ?>
			    <div class="reglayout">Default Layout</div>
				<?php elseif(isset($_GET['sing'])) : ?>
			   		<div class="singlayout">Single Layout</div>
						<?php elseif(isset($_GET['mult'])) : ?>
						   <div class="multlayout">Multiple Layout</div>
							<?php elseif(isset($_GET['process'] and $_GET['run'])) : ?>
							   <div class="simuprocess">Simulation in Process</div>
			<?php endif; ?>

							
		</div>
		<div class="footer"></div>
	</div>

</body>
</html>