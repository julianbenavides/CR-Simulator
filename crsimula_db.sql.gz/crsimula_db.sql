-- MySQL dump 10.13  Distrib 5.5.23, for Linux (x86_64)
--
-- Host: localhost    Database: crsimula_db
-- ------------------------------------------------------
-- Server version	5.5.23-55

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bands`
--

DROP TABLE IF EXISTS `bands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bands` (
  `band_id` int(11) NOT NULL AUTO_INCREMENT,
  `bandfreq` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`band_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bands`
--

LOCK TABLES `bands` WRITE;
/*!40000 ALTER TABLE `bands` DISABLE KEYS */;
INSERT INTO `bands` (`band_id`, `bandfreq`, `name`) VALUES (1,2345,'SHF');
/*!40000 ALTER TABLE `bands` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `channels`
--

DROP TABLE IF EXISTS `channels`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `channels` (
  `channel_id` int(11) NOT NULL AUTO_INCREMENT,
  `band` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`channel_id`),
  KEY `band` (`band`),
  CONSTRAINT `band` FOREIGN KEY (`band`) REFERENCES `bands` (`band_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `channels`
--

LOCK TABLES `channels` WRITE;
/*!40000 ALTER TABLE `channels` DISABLE KEYS */;
INSERT INTO `channels` (`channel_id`, `band`, `name`) VALUES (1,1,'ch1'),(2,1,'ch2'),(3,1,'ch3'),(4,1,'ch4'),(5,1,'ch5');
/*!40000 ALTER TABLE `channels` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `collision_log`
--

DROP TABLE IF EXISTS `collision_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `collision_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `timestamp` datetime NOT NULL,
  `puser_collided` varchar(10) NOT NULL,
  `suser_collided` varchar(10) NOT NULL,
  `band` int(11) NOT NULL,
  `channel` int(11) NOT NULL,
  `frame` int(11) NOT NULL,
  `slot` int(11) NOT NULL,
  `cycle` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `collision_log`
--

LOCK TABLES `collision_log` WRITE;
/*!40000 ALTER TABLE `collision_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `collision_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `data_transmitted`
--

DROP TABLE IF EXISTS `data_transmitted`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `data_transmitted` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `usrid` int(11) NOT NULL,
  `data_left` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `usrid` (`usrid`),
  CONSTRAINT `data_transmitted_ibfk_1` FOREIGN KEY (`usrid`) REFERENCES `users` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `data_transmitted`
--

LOCK TABLES `data_transmitted` WRITE;
/*!40000 ALTER TABLE `data_transmitted` DISABLE KEYS */;
/*!40000 ALTER TABLE `data_transmitted` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `frames`
--

DROP TABLE IF EXISTS `frames`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `frames` (
  `frame_id` int(11) NOT NULL AUTO_INCREMENT,
  `band_fk` int(11) NOT NULL,
  `channel_fk` int(11) NOT NULL,
  `frame_cycle` double NOT NULL,
  `bytesize` int(11) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`frame_id`),
  KEY `band_fk` (`band_fk`),
  KEY `channel_fk` (`channel_fk`),
  CONSTRAINT `band_fk` FOREIGN KEY (`band_fk`) REFERENCES `bands` (`band_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `channel_fk` FOREIGN KEY (`channel_fk`) REFERENCES `channels` (`channel_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `frames`
--

LOCK TABLES `frames` WRITE;
/*!40000 ALTER TABLE `frames` DISABLE KEYS */;
/*!40000 ALTER TABLE `frames` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sim_progress`
--

DROP TABLE IF EXISTS `sim_progress`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sim_progress` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ongoing` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sim_progress`
--

LOCK TABLES `sim_progress` WRITE;
/*!40000 ALTER TABLE `sim_progress` DISABLE KEYS */;
INSERT INTO `sim_progress` (`id`, `ongoing`) VALUES (1,'N');
/*!40000 ALTER TABLE `sim_progress` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `slots`
--

DROP TABLE IF EXISTS `slots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `slots` (
  `slot_id` int(11) NOT NULL AUTO_INCREMENT,
  `b_id` int(11) NOT NULL,
  `c_id` int(11) NOT NULL,
  `f_id` int(11) NOT NULL,
  `bytesize` int(11) NOT NULL,
  PRIMARY KEY (`slot_id`),
  KEY `b_id` (`b_id`),
  KEY `c_id` (`c_id`),
  KEY `f_id` (`f_id`),
  CONSTRAINT `b_id` FOREIGN KEY (`b_id`) REFERENCES `bands` (`band_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `c_id` FOREIGN KEY (`c_id`) REFERENCES `channels` (`channel_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `f_id` FOREIGN KEY (`f_id`) REFERENCES `frames` (`frame_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `slots`
--

LOCK TABLES `slots` WRITE;
/*!40000 ALTER TABLE `slots` DISABLE KEYS */;
/*!40000 ALTER TABLE `slots` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usage`
--

DROP TABLE IF EXISTS `usage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usage` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `usrid` int(11) NOT NULL,
  `bandid` int(11) NOT NULL,
  `chanid` int(11) NOT NULL,
  `framid` int(11) NOT NULL,
  `slotid` int(11) NOT NULL,
  `cycle` double NOT NULL,
  `used` varchar(1) NOT NULL,
  `timestamp` datetime NOT NULL,
  PRIMARY KEY (`uid`),
  KEY `usrid` (`usrid`),
  KEY `bandid` (`bandid`),
  KEY `chanid` (`chanid`),
  KEY `framid` (`framid`),
  KEY `slotid` (`slotid`),
  CONSTRAINT `bandid` FOREIGN KEY (`bandid`) REFERENCES `bands` (`band_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `chanid` FOREIGN KEY (`chanid`) REFERENCES `channels` (`channel_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `framid` FOREIGN KEY (`framid`) REFERENCES `frames` (`frame_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `slotid` FOREIGN KEY (`slotid`) REFERENCES `slots` (`slot_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `usrid` FOREIGN KEY (`usrid`) REFERENCES `users` (`user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usage`
--

LOCK TABLES `usage` WRITE;
/*!40000 ALTER TABLE `usage` DISABLE KEYS */;
/*!40000 ALTER TABLE `usage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `ip` varchar(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `is_primary` varchar(4) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2012-08-13 11:42:08
